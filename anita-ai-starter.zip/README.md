# Anita AI — Android + Backend Starter

This is a real source-code starter for Anita AI. It is not a prebuilt APK and has not yet been deployed or device-tested.

## Included in this first build
- Native Android app (Kotlin, Android 10 / API 29 minimum)
- Text chat UI
- Android SpeechRecognizer tap-to-talk
- Android TextToSpeech spoken responses
- Launch installed apps by common name (best-effort package matching)
- Local reminder scheduling and notification
- Backend API for AI chat, with the model API key kept on the server
- GitHub Actions workflow to build a debug APK and attach it to a workflow run

## Not included yet
- Always-on "Hey Anita" wake phrase
- Floating overlay
- Notification reading / reply actions
- Direct sending to WhatsApp, Instagram, Messenger or Telegram
- Verified web search integration
These require additional permissions/integrations and must be added and tested separately.

## Build an APK using GitHub Actions
1. Upload the contents of this project into your `anita-ai` repository (not the ZIP file itself).
2. Open the repository's **Actions** tab.
3. Enable Actions if GitHub asks.
4. Open **Build Anita AI APK**, then press **Run workflow** (or push a commit to `main`).
5. Wait for the workflow to finish successfully.
6. Open the completed run, scroll to **Artifacts**, and download `anita-ai-debug-apk`.
7. Extract the ZIP artifact and install `app-debug.apk` on your Android phone. Android may ask you to allow installs from the browser or file manager.

A debug APK is suitable for personal testing. It is not a signed release APK for Play Store distribution.

## Backend
The backend is in `backend/`. Deploy it as a Node web service on Render from this repository with:
- Root directory: `backend`
- Build command: `npm install`
- Start command: `npm start`
- Environment variable: `AI_API_KEY` (secret; set only in Render)
- Optional `AI_BASE_URL` (defaults to OpenAI-compatible endpoint)
- Optional `AI_MODEL` (defaults to `gpt-4o-mini`; availability/pricing depends on your provider/account)

The backend is designed for an OpenAI-compatible chat-completions API. A usable API key may require a paid account; do not assume inference is free. If you have a genuinely free compatible provider, set its base URL and model in Render. Never place the key in Android source or GitHub.

The Android app needs the public Render service URL. Set `API_BASE_URL` in `app/build.gradle.kts` to your deployed service URL, ending in `/` (example: `https://your-service.onrender.com/`), then rebuild the APK.

## Important security notes
- The starter backend has basic request validation and a simple optional `APP_TOKEN` bearer token.
- Set a strong `APP_TOKEN` in Render and set the same value in `app/build.gradle.kts` before building if you want basic access control. For a production app, avoid hardcoding a shared token in an APK; use a proper authentication design.
- Public Render services can be reached by anyone who knows the URL if you do not configure authentication/rate limiting.
- Do not send sensitive messages or credentials to a model unless you understand the provider's data practices.
