plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ai.anita.personal"
    compileSdk = 35

    defaultConfig {
        applicationId = "ai.anita.personal"
        minSdk = 29
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
        buildConfigField("String", "API_BASE_URL", "\"https://YOUR-RENDER-SERVICE.onrender.com/\"")
        buildConfigField("String", "APP_TOKEN", "\"CHANGE_ME_IF_ENABLED\"")
    }
    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
