package ai.anita.personal

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.Calendar
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var log: TextView
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private var speakReplies = true
    private var lastAssistantReply = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        requestAudioPermissionIfNeeded()
        buildUi()
        addLine("Anita", "Hi! I'm Anita AI. I can chat, listen when you tap the mic, speak replies, open apps, and create local reminders.")
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 18)
            setBackgroundColor(0xFF10111A.toInt())
        }
        val title = TextView(this).apply {
            text = "ANITA AI"
            textSize = 25f
            setTextColor(0xFFB8A7FF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 4, 0, 12)
        }
        val subtitle = TextView(this).apply {
            text = "Your personal assistant"
            textSize = 13f
            setTextColor(0xFFB9BBCB.toInt())
            gravity = Gravity.CENTER
        }
        log = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFFF1F1F7.toInt())
            setPadding(4, 12, 4, 12)
        }
        val scroll = ScrollView(this).apply { addView(log) }
        input = EditText(this).apply {
            hint = "Message Anita..."
            setHintTextColor(0xFF999AAA.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(14, 10, 14, 10)
            setSingleLine(false)
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val mic = Button(this).apply { text = "🎙"; setOnClickListener { startSpeech() } }
        val send = Button(this).apply { text = "Send"; setOnClickListener { val s=input.text.toString().trim(); if(s.isNotEmpty()){input.setText(""); handleCommand(s)} } }
        row.addView(mic, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(send, LinearLayout.LayoutParams(0, -2, 1f))
        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val apps = Button(this).apply { text = "Open app"; setOnClickListener { input.setText("Open WhatsApp") } }
        val reminder = Button(this).apply { text = "Reminder"; setOnClickListener { input.setText("Remind me to study in 1 minute") } }
        val voice = Button(this).apply { text = "Voice on/off"; setOnClickListener { speakReplies = !speakReplies; Toast.makeText(this@MainActivity, "Spoken replies: $speakReplies", Toast.LENGTH_SHORT).show() } }
        quick.addView(apps, LinearLayout.LayoutParams(0, -2, 1f))
        quick.addView(reminder, LinearLayout.LayoutParams(0, -2, 1f))
        quick.addView(voice, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(title)
        root.addView(subtitle)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(input)
        root.addView(row)
        root.addView(quick)
        setContentView(root)
    }

    private fun addLine(who: String, message: String) {
        runOnUiThread {
            log.append("\n\n$who: $message")
        }
    }

    private fun handleCommand(text: String) {
        addLine("You", text)
        val lower = text.lowercase(Locale.ROOT)
        when {
            lower == "stop talking" || lower.contains("stop speaking") -> {
                if (::tts.isInitialized) tts.stop()
                addLine("Anita", "Okay, I've stopped speaking.")
            }
            lower.startsWith("open ") -> openApp(text.substringAfter("open ").trim())
            lower.startsWith("remind me to ") -> createReminder(text)
            lower == "read that aloud" && lastAssistantReply.isNotBlank() -> speak(lastAssistantReply)
            lower.startsWith("shorten it") && lastAssistantReply.isNotBlank() -> askAi("Rewrite this shorter:\n$lastAssistantReply")
            lower.startsWith("make it funnier") && lastAssistantReply.isNotBlank() -> askAi("Rewrite this to be funnier:\n$lastAssistantReply")
            lower.startsWith("make it more flirty") && lastAssistantReply.isNotBlank() -> askAi("Rewrite this to be more flirty while respectful:\n$lastAssistantReply")
            lower.startsWith("search ") -> {
                val query = text.substringAfter("search ").trim()
                val i = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com/search?q=" + android.net.Uri.encode(query)))
                try { startActivity(i); addLine("Anita", "I've opened a web search for: $query") }
                catch (_: Exception) { addLine("Anita", "I couldn't open the browser on this device.") }
            }
            else -> askAi(text)
        }
    }

    private fun openApp(name: String) {
        val candidates = mapOf(
            "whatsapp" to listOf("com.whatsapp"),
            "instagram" to listOf("com.instagram.android"),
            "youtube" to listOf("com.google.android.youtube"),
            "facebook" to listOf("com.facebook.katana"),
            "messenger" to listOf("com.facebook.orca"),
            "telegram" to listOf("org.telegram.messenger"),
            "chrome" to listOf("com.android.chrome", "com.google.android.chrome"),
            "settings" to listOf("com.android.settings")
        )
        val key = candidates.keys.firstOrNull { name.lowercase(Locale.ROOT).contains(it) }
        val packages = key?.let { candidates[it] } ?: emptyList()
        for (pkg in packages) {
            val launch = packageManager.getLaunchIntentForPackage(pkg)
            if (launch != null) {
                try { startActivity(launch); addLine("Anita", "Opened $key."); return }
                catch (_: Exception) { }
            }
        }
        if (name.contains("setting", true)) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)); addLine("Anita", "Opened Android Settings."); return } catch (_: Exception) {}
        }
        addLine("Anita", "I couldn't find a launchable app matching \"$name\". Check that it is installed.")
    }

    private fun createReminder(command: String) {
        val message = command.substringAfter("remind me to ", "your task").trim()
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, ReminderReceiver::class.java).putExtra("message", message)
        val pi = PendingIntent.getBroadcast(this, (System.currentTimeMillis() % Int.MAX_VALUE).toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val trigger = System.currentTimeMillis() + 60_000L
        try {
            alarm.set(AlarmManager.RTC_WAKEUP, trigger, pi)
            addLine("Anita", "I've scheduled a local reminder for \"$message\" in about one minute. This starter currently interprets reminders as one minute from now; specific times like 7 PM are not implemented yet.")
        } catch (_: Exception) {
            addLine("Anita", "I couldn't schedule the reminder. Please check Android alarm/notification settings.")
        }
    }

    private fun askAi(prompt: String) {
        addLine("Anita", "Thinking…")
        thread {
            var answer: String
            try {
                val url = URL(BuildConfig.API_BASE_URL.trimEnd('/') + "/chat")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 30000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    if (BuildConfig.APP_TOKEN != "CHANGE_ME_IF_ENABLED") setRequestProperty("Authorization", "Bearer ${BuildConfig.APP_TOKEN}")
                }
                val body = JSONObject().put("message", prompt).toString()
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                if (code !in 200..299) throw Exception("Backend returned HTTP $code: $response")
                answer = JSONObject(response).optString("reply", "I received an empty response.")
                conn.disconnect()
            } catch (e: Exception) {
                answer = "I couldn't reach the AI backend. Check the Render URL and backend setup. Details: ${e.message ?: "connection error"}"
            }
            lastAssistantReply = answer
            addLine("Anita", answer)
            if (speakReplies) speak(answer)
        }
    }

    private fun startSpeech() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            addLine("Anita", "Speech recognition isn't available on this device. Check whether a speech recognition service is installed.")
            return
        }
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to Anita")
            }
            startActivityForResult(intent, 42)
        } catch (e: Exception) {
            addLine("Anita", "Couldn't start speech recognition: ${e.message}")
        }
    }

    @Deprecated("Deprecated by Android but compatible with Android 10")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42 && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) handleCommand(spoken) else addLine("Anita", "I didn't catch that. Please try again.")
        }
    }

    private fun requestAudioPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts.language = Locale.getDefault()
    }

    private fun speak(text: String) {
        runOnUiThread {
            try { tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "anita-reply") } catch (_: Exception) {}
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
